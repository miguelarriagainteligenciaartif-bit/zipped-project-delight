# Debug Info - Paso 8

## Para diagnosticar el problema:

1. **Abre la aplicación** en tu navegador
2. **Abre las herramientas de desarrollador** (F12)
3. Ve a la pestaña **Console**
4. **Navega hasta el paso 8**
5. **Haz clic en "SÍ - Ejecuté Trade"**
6. **Rellena todos los campos**:
   - Selecciona un radio button de FVG (1, 2 o 3+)
   - Dirección: LONG o SHORT
   - Precio Entrada: cualquier número (ej: 16000)
   - Stop Loss: cualquier número (ej: 15950)
   - Take Profit: cualquier número (ej: 16100)
7. **Haz clic en "Finalizar y Guardar"**

## Qué deberías ver en la consola:

```
selectTradeDecision llamado con: true
checklistData.hadEntry actualizado a: true
Recopilando datos del trade: {direction: "LONG", entry: 16000, sl: 15950, tp: 16100, lots: 1, notes: "", fvgCount: "1"}
```

## Si ves un error que dice "Faltan campos requeridos":

Copia **TODO** el contenido de la consola y envíamelo para ver qué campo está faltando.

## Posibles problemas:

1. **Los botones de decisión no funcionan** → Verás que NO se llama a `selectTradeDecision`
2. **Los campos no se leen correctamente** → Verás valores `undefined` o `false` en la consola
3. **El radio button de FVG no está seleccionado** → `fvgCount: undefined`

---

**Por favor prueba esto y dime qué ves en la consola.**
