/**
 * Aplicación principal Edgecore NASDAQ
 * Gestiona la interfaz de usuario y la lógica del wizard
 */

const App = {
    currentStep: 1,
    totalSteps: 8,
    checklistData: {},
    charts: {
        weekday: null,
        correlation: null
    },

    /**
     * Inicializa la aplicación
     */
    init() {
        this.checkAuth();
        this.attachEventListeners();
        this.startNYClock();
    },

    /**
     * Verifica la autenticación del usuario
     */
    checkAuth() {
        const currentUser = StorageManager.getCurrentUser();
        
        if (!currentUser) {
            this.showAuthScreen();
        } else {
            this.showAppScreen();
        }
    },

    /**
     * Adjunta event listeners a los elementos
     */
    attachEventListeners() {
        // Autenticación
        document.getElementById('showRegister').addEventListener('click', (e) => {
            e.preventDefault();
            this.toggleAuthForms('register');
        });

        document.getElementById('showLogin').addEventListener('click', (e) => {
            e.preventDefault();
            this.toggleAuthForms('login');
        });

        document.getElementById('loginFormElement').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleLogin();
        });

        document.getElementById('registerFormElement').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleRegister();
        });

        // Navegación
        document.querySelectorAll('.menu-item').forEach(item => {
            item.addEventListener('click', () => {
                this.switchView(item.dataset.view);
            });
        });

        // Logout
        document.getElementById('logoutBtn').addEventListener('click', () => {
            this.handleLogout();
        });

        // Wizard navigation
        document.getElementById('btnPrev').addEventListener('click', () => {
            this.prevStep();
        });

        document.getElementById('btnNext').addEventListener('click', () => {
            this.nextStep();
        });

        document.getElementById('btnFinish').addEventListener('click', () => {
            this.finishWizard();
        });

        // Trade decision - usar delegación de eventos
        document.addEventListener('click', (e) => {
            const yesBtn = e.target.closest('#btnYesEntry');
            const noBtn = e.target.closest('#btnNoEntry');
            
            if (yesBtn) {
                e.preventDefault();
                this.selectTradeDecision(true);
            } else if (noBtn) {
                e.preventDefault();
                this.selectTradeDecision(false);
            }
        });

        // R:R calculation ya no se necesita (campos eliminados)

        // Filters
        document.getElementById('filterPeriod').addEventListener('change', () => {
            this.loadHistoryView();
        });

        document.getElementById('filterType').addEventListener('change', () => {
            this.loadHistoryView();
        });
    },

    /**
     * Inicia el reloj de NY
     */
    startNYClock() {
        this.updateNYClock();
        setInterval(() => this.updateNYClock(), 1000);
    },

    /**
     * Actualiza el reloj de NY y el estado de la ventana
     */
    updateNYClock() {
        const nyTime = StorageManager.getNYTime();
        const timeString = StorageManager.formatTime(nyTime);
        
        const clockElement = document.getElementById('nyTime');
        if (clockElement) {
            clockElement.textContent = timeString;
        }

        // Actualizar estado de ventana
        const isOpen = StorageManager.isWithinTradingWindow();
        this.updateWindowStatus(isOpen);
    },

    /**
     * Actualiza el estado de la ventana de trading
     */
    updateWindowStatus(isOpen) {
        const statusElements = document.querySelectorAll('.window-status, .window-indicator');
        
        statusElements.forEach(el => {
            el.classList.remove('open', 'closed');
            el.classList.add(isOpen ? 'open' : 'closed');
            
            const span = el.querySelector('span');
            if (span && el.classList.contains('window-status')) {
                span.textContent = isOpen ? 'Ventana Abierta' : 'Mercado Cerrado';
            }
        });
    },

    /**
     * Cambia entre formularios de login y registro
     */
    toggleAuthForms(form) {
        const loginForm = document.getElementById('loginForm');
        const registerForm = document.getElementById('registerForm');
        const authMessage = document.getElementById('authMessage');

        authMessage.style.display = 'none';
        authMessage.className = 'auth-message';

        if (form === 'register') {
            loginForm.style.display = 'none';
            registerForm.style.display = 'block';
        } else {
            registerForm.style.display = 'none';
            loginForm.style.display = 'block';
        }
    },

    /**
     * Maneja el login de usuario
     */
    handleLogin() {
        const username = document.getElementById('loginUsername').value.trim();
        const password = document.getElementById('loginPassword').value;

        const result = StorageManager.loginUser(username, password);
        
        if (result.success) {
            this.showMessage(result.message, 'success');
            setTimeout(() => {
                this.showAppScreen();
            }, 500);
        } else {
            this.showMessage(result.message, 'error');
        }
    },

    /**
     * Maneja el registro de usuario
     */
    handleRegister() {
        const username = document.getElementById('registerUsername').value.trim();
        const password = document.getElementById('registerPassword').value;
        const passwordConfirm = document.getElementById('registerPasswordConfirm').value;

        if (password !== passwordConfirm) {
            this.showMessage('Las contraseñas no coinciden', 'error');
            return;
        }

        const result = StorageManager.registerUser(username, password);
        
        if (result.success) {
            this.showMessage(result.message, 'success');
            setTimeout(() => {
                this.toggleAuthForms('login');
                document.getElementById('loginUsername').value = username;
            }, 1000);
        } else {
            this.showMessage(result.message, 'error');
        }
    },

    /**
     * Maneja el logout
     */
    handleLogout() {
        if (confirm('¿Estás seguro de que quieres cerrar sesión?')) {
            StorageManager.logoutUser();
            this.showAuthScreen();
            this.showToast('Sesión cerrada exitosamente', 'success');
        }
    },

    /**
     * Muestra un mensaje en la pantalla de autenticación
     */
    showMessage(message, type) {
        const authMessage = document.getElementById('authMessage');
        authMessage.textContent = message;
        authMessage.className = `auth-message ${type}`;
        authMessage.style.display = 'block';
    },

    /**
     * Muestra la pantalla de autenticación
     */
    showAuthScreen() {
        document.getElementById('authScreen').style.display = 'flex';
        document.getElementById('appScreen').style.display = 'none';
        
        document.getElementById('loginFormElement').reset();
        document.getElementById('registerFormElement').reset();
        document.getElementById('authMessage').style.display = 'none';
    },

    /**
     * Muestra la pantalla principal de la aplicación
     */
    showAppScreen() {
        document.getElementById('authScreen').style.display = 'none';
        document.getElementById('appScreen').style.display = 'flex';

        const username = StorageManager.getCurrentUser();
        document.getElementById('currentUserName').textContent = username;

        // Cargar checklist de hoy
        this.loadTodayChecklist();
        
        // Mostrar fecha de hoy (usando hora de Nueva York)
        const todayNY = StorageManager.getNYTime();
        const todayKey = StorageManager.formatDateKey(todayNY);
        document.getElementById('todayDate').textContent = StorageManager.formatDateDisplay(todayKey);
    },

    /**
     * Cambia la vista activa
     */
    switchView(view) {
        // Actualizar menú
        document.querySelectorAll('.menu-item').forEach(item => {
            item.classList.remove('active');
            if (item.dataset.view === view) {
                item.classList.add('active');
            }
        });

        // Actualizar vistas
        document.querySelectorAll('.view-container').forEach(container => {
            container.classList.remove('active');
        });

        const viewElement = document.getElementById(`${view}View`);
        if (viewElement) {
            viewElement.classList.add('active');

            // Cargar datos específicos de la vista
            if (view === 'history') {
                this.loadHistoryView();
            } else if (view === 'statistics') {
                this.loadStatisticsView();
            } else if (view === 'checklist') {
                this.loadTodayChecklist();
            }
        }
    },

    /**
     * Carga el checklist de hoy
     */
    loadTodayChecklist() {
        const todayData = StorageManager.getTodayChecklist();
        this.checklistData = todayData;

        // Renderizar wizard steps
        this.renderWizardSteps();
        
        // Cargar datos en checkboxes
        this.loadCheckboxesFromData();
        
        // Reset wizard
        this.currentStep = 1;
        this.updateWizard();
    },

    /**
     * Renderiza los pasos del wizard
     */
    renderWizardSteps() {
        const container = document.getElementById('wizardSteps');
        if (!container) return;

        container.innerHTML = `
            ${this.renderStep1()}
            ${this.renderStep2()}
            ${this.renderStep3()}
            ${this.renderStep4()}
            ${this.renderStep5()}
            ${this.renderStep6()}
            ${this.renderStep7()}
            ${this.renderStep8()}
        `;
    },

    renderStep1() {
        return `
            <div class="wizard-step active" id="wizardStep1">
                <h2 class="step-title">
                    <i class="fas fa-brain"></i>
                    Paso 1: El Poder de la Espera
                </h2>
                <p class="step-subtitle">Preparación mental antes de operar</p>
                
                <div class="checklist-section">
                    <div class="checklist-item">
                        <input type="checkbox" id="prep1" data-step="preparacion" data-item="0">
                        <label for="prep1">Limpiar y ordenar el espacio de trabajo
                            <small>Una acción sencilla incrementa 94% la probabilidad de éxito en tu ejecución</small>
                        </label>
                    </div>
                    <div class="checklist-item">
                        <input type="checkbox" id="prep2" data-step="preparacion" data-item="1">
                        <label for="prep2">Activar aromaterapia (difusor o incienso)
                            <small>Científicamente comprobado que mejora el enfoque durante la sesión</small>
                        </label>
                    </div>
                    <div class="checklist-item">
                        <input type="checkbox" id="prep3" data-step="preparacion" data-item="2">
                        <label for="prep3">Revisar objetivo del día
                            <small>Ser la mejor trader ejecutando el sistema Edgecore</small>
                        </label>
                    </div>
                </div>

                <div class="motivation-box">
                    <i class="fas fa-quote-left"></i>
                    <p>"Y todo lo que hagáis, hacedlo de corazón, como para el Señor y no para los hombres; sabiendo que del Señor recibiréis la recompensa de la herencia, porque a Cristo el Señor servís."</p>
                    <span class="quote-ref">— Colosenses 3:23-24</span>
                </div>

                <div class="alert-box warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>PROHIBIDO DUDAR</strong>
                </div>
            </div>
        `;
    },

    renderStep2() {
        return `
            <div class="wizard-step" id="wizardStep2">
                <h2 class="step-title">
                    <i class="fas fa-calendar-alt"></i>
                    Paso 2: Análisis Mensual
                </h2>
                <p class="step-subtitle">Revisar solo una vez al mes, al inicio</p>
                
                <div class="alert-box info">
                    <i class="fas fa-info-circle"></i>
                    <div>Este análisis se hace <strong>SOLO el primer día del mes</strong>. Ignora el resto del mes.</div>
                </div>

                <div class="checklist-section">
                    <div class="checklist-item">
                        <input type="checkbox" id="monthly1" data-step="mensual" data-item="0">
                        <label for="monthly1">Marcar máximos mensuales</label>
                    </div>
                    <div class="checklist-item">
                        <input type="checkbox" id="monthly2" data-step="mensual" data-item="1">
                        <label for="monthly2">Marcar mínimos mensuales</label>
                    </div>
                </div>
                
                <div class="alert-box warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>IMPORTANTE:</strong> En temporalidad mensual NO se marcan zonas. Solo observar contexto.
                </div>

                <div class="motivation-box">
                    <i class="fas fa-quote-left"></i>
                    <p>"Y el Señor estaba con José, y fue varón próspero."</p>
                    <span class="quote-ref">— Génesis 39:23</span>
                </div>
            </div>
        `;
    },

    renderStep3() {
        return `
            <div class="wizard-step" id="wizardStep3">
                <h2 class="step-title">
                    <i class="fas fa-calendar-week"></i>
                    Paso 3: Análisis Semanal
                </h2>
                <p class="step-subtitle">Revisar cada lunes</p>
                
                <div class="alert-box info">
                    <i class="fas fa-info-circle"></i>
                    <div>Este análisis se hace <strong>SOLO los lunes</strong> al inicio de la semana.</div>
                </div>

                <div class="checklist-section">
                    <div class="checklist-item">
                        <input type="checkbox" id="weekly1" data-step="semanal" data-item="0">
                        <label for="weekly1">Revisar calendario de noticias económicas de la semana</label>
                    </div>
                    <div class="checklist-item">
                        <input type="checkbox" id="weekly2" data-step="semanal" data-item="1">
                        <label for="weekly2">Marcar máximos semanales</label>
                    </div>
                    <div class="checklist-item">
                        <input type="checkbox" id="weekly3" data-step="semanal" data-item="2">
                        <label for="weekly3">Marcar mínimos semanales</label>
                    </div>
                </div>
                
                <div class="alert-box warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>PROHIBIDO DUDAR</strong>
                </div>
            </div>
        `;
    },

    renderStep4() {
        return `
            <div class="wizard-step" id="wizardStep4">
                <h2 class="step-title">
                    <i class="fas fa-calendar-day"></i>
                    Paso 4: Análisis Diario
                </h2>
                <p class="step-subtitle">Revisar cada día - Análisis a las 9:15 AM (NY)</p>
                
                <div class="alert-box critical">
                    <i class="fas fa-exclamation-circle"></i>
                    <div><strong>PROHIBIDO DUDAR</strong> - Analizar a las <strong>9:15 AM</strong></div>
                </div>

                <div class="checklist-section">
                    <div class="checklist-item">
                        <input type="checkbox" id="daily1" data-step="diario" data-item="0">
                        <label for="daily1">Revisar calendario de noticias del día</label>
                    </div>
                    <div class="checklist-item">
                        <input type="checkbox" id="daily2" data-step="diario" data-item="1">
                        <label for="daily2">Marcar máximos diarios en gráfico</label>
                    </div>
                    <div class="checklist-item">
                        <input type="checkbox" id="daily3" data-step="diario" data-item="2">
                        <label for="daily3">Marcar mínimos diarios en gráfico</label>
                    </div>
                    <div class="checklist-item">
                        <input type="checkbox" id="daily4" data-step="diario" data-item="3">
                        <label for="daily4">Marcar zonas de interés: FVG, OB, 50OB</label>
                    </div>
                </div>
            </div>
        `;
    },

    renderStep5() {
        return `
            <div class="wizard-step" id="wizardStep5">
                <h2 class="step-title">
                    <i class="fas fa-clock"></i>
                    Paso 5: Análisis 4 Horas
                </h2>
                <p class="step-subtitle">Refinamiento del análisis</p>
                
                <div class="alert-box warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>PROHIBIDO DUDAR</strong>
                </div>

                <div class="checklist-section">
                    <div class="checklist-item">
                        <input type="checkbox" id="h41" data-step="h4" data-item="0">
                        <label for="h41">Verificar confluencias con zonas diarias</label>
                    </div>
                    <div class="checklist-item">
                        <input type="checkbox" id="h42" data-step="h4" data-item="1">
                        <label for="h42">Marcar zonas de interés 4H: FVG, OB, 50OB</label>
                    </div>
                </div>
            </div>
        `;
    },

    renderStep6() {
        return `
            <div class="wizard-step" id="wizardStep6">
                <h2 class="step-title">
                    <i class="fas fa-stopwatch"></i>
                    Paso 6: Análisis 1 Hora
                </h2>
                <p class="step-subtitle">Análisis entre 9:27 - 9:29 AM (NY)</p>
                
                <div class="alert-box critical">
                    <i class="fas fa-exclamation-circle"></i>
                    <div><strong>PROHIBIDO DUDAR</strong> - Analizar entre <strong>9:27 - 9:29 AM</strong></div>
                </div>

                <div class="checklist-section">
                    <div class="checklist-item">
                        <input type="checkbox" id="h11" data-step="h1" data-item="0">
                        <label for="h11">Verificar confluencias con zonas de diario y H4
                            <small>¿Las zonas marcadas en diario y H4 coinciden?</small>
                        </label>
                    </div>
                    <div class="checklist-item">
                        <input type="checkbox" id="h12" data-step="h1" data-item="1">
                        <label for="h12">Identificar zonas de 1H cercanas al precio actual
                            <small>¿Qué zonas de interés hay cerca del precio ahora?</small>
                        </label>
                    </div>
                    <div class="checklist-item">
                        <input type="checkbox" id="h13" data-step="h1" data-item="2">
                        <label for="h13">Determinar la dirección del precio con la vela de H1 entre las 9:27 y 9:29 hora New York
                            <small>Observar si tiene más mecha por la parte de arriba o por la parte de abajo</small>
                        </label>
                    </div>
                </div>
            </div>
        `;
    },

    renderStep7() {
        return `
            <div class="wizard-step" id="wizardStep7">
                <h2 class="step-title">
                    <i class="fas fa-crosshairs"></i>
                    Paso 7: Modelo de Entrada
                </h2>
                <p class="step-subtitle">Confirmación a las 9:30 AM (NY)</p>
                
                <div class="alert-box critical">
                    <i class="fas fa-clock"></i>
                    <div><strong>VENTANA DE EJECUCIÓN: 9:30 - 10:15 AM (NY)</strong></div>
                </div>

                <div class="checklist-section">
                    <div class="checklist-item">
                        <input type="checkbox" id="entry1" data-step="entrada" data-item="0">
                        <label for="entry1">Todos los análisis multi-timeframe completos</label>
                    </div>
                </div>

                <div class="alert-box warning">
                    <i class="fas fa-info-circle"></i>
                    <div>Si NO se cumplen las condiciones entre 9:30 - 10:15 AM, <strong>NO hay entrada hoy</strong>. Esperar hasta mañana.</div>
                </div>
            </div>
        `;
    },

    renderStep8() {
        return `
            <div class="wizard-step" id="wizardStep8">
                <h2 class="step-title">
                    <i class="fas fa-pen"></i>
                    Paso 8: Registro del Trade
                </h2>
                <p class="step-subtitle">Decisión final y registro</p>

                <div class="trade-decision">
                    <h3>¿Hubo entrada hoy?</h3>
                    <div class="decision-buttons">
                        <button type="button" class="btn-decision" id="btnYesEntry">
                            <i class="fas fa-check-circle"></i>
                            SÍ - Ejecuté Trade
                        </button>
                        <button type="button" class="btn-decision" id="btnNoEntry">
                            <i class="fas fa-times-circle"></i>
                            NO - Sin Entrada
                        </button>
                    </div>
                </div>

                <div id="tradeForm" style="display: none;">
                    <div class="fvg-rules">
                        <h3>Reglas FVG - ¿Cuántos FVG identificaste?</h3>
                        <div class="fvg-options">
                            <label class="fvg-option">
                                <input type="radio" name="fvgCount" value="1">
                                <div class="fvg-card">
                                    <strong>1 FVG</strong>
                                    <p>→ Ejecutar en el único FVG</p>
                                    <p>→ SL: Proteger 3 velas del FVG</p>
                                    <p>→ Si no 1:1.2, esperar descuento</p>
                                </div>
                            </label>
                            <label class="fvg-option">
                                <input type="radio" name="fvgCount" value="2">
                                <div class="fvg-card">
                                    <strong>2 FVG</strong>
                                    <p>→ Ejecutar en el ÚLTIMO FVG</p>
                                    <p>→ SL: Proteger 3 velas del 1er FVG</p>
                                    <p>→ Si no 1:1.2, descuento o vela envolvente</p>
                                </div>
                            </label>
                            <label class="fvg-option">
                                <input type="radio" name="fvgCount" value="3">
                                <div class="fvg-card">
                                    <strong>3+ FVG</strong>
                                    <p>→ Esperar protocolo vela envolvente</p>
                                    <p>→ NO ejecutar sin protocolo</p>
                                </div>
                            </label>
                        </div>
                    </div>

                    <div class="trade-data-form">
                        <div class="alert-box warning">
                            <i class="fas fa-exclamation-triangle"></i>
                            <div><strong>RECORDATORIO:</strong> NO mover el SL (sin break even). Solo TP o SL inicial.</div>
                        </div>

                        <div class="form-group">
                            <label>Notas Adicionales</label>
                            <textarea id="tradeNotes" rows="3" placeholder="Ej: Confluencia perfecta con zona semanal..."></textarea>
                        </div>
                    </div>
                </div>

                <div id="noEntryForm" style="display: none;">
                    <div class="no-entry-reasons">
                        <h3>¿Por qué no ejecutaste?</h3>
                        <div class="checklist-section">
                            <div class="checklist-item">
                                <input type="checkbox" id="reason1">
                                <label for="reason1">R:R no era mínimo 1:1.2</label>
                            </div>
                            <div class="checklist-item">
                                <input type="checkbox" id="reason2">
                                <label for="reason2">Fuera de ventana 9:30-10:15 AM</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Notas Adicionales</label>
                            <textarea id="noEntryNotes" rows="3" placeholder="Describe qué observaste hoy..."></textarea>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

    /**
     * Carga los checkboxes desde los datos guardados
     */
    loadCheckboxesFromData() {
        const checklist = this.checklistData.checklist;
        
        StorageManager.CONFIG.STEPS.forEach(step => {
            const stepData = checklist[step.id];
            if (!stepData) return;

            stepData.forEach((checked, index) => {
                const checkbox = document.querySelector(`input[data-step="${step.id}"][data-item="${index}"]`);
                if (checkbox) {
                    checkbox.checked = checked;
                }
            });
        });
    },

    /**
     * Guarda los datos de los checkboxes
     */
    saveCheckboxesToData() {
        const checkboxes = document.querySelectorAll('[data-step][data-item]');
        
        checkboxes.forEach(checkbox => {
            const step = checkbox.dataset.step;
            const item = parseInt(checkbox.dataset.item);
            
            if (!this.checklistData.checklist[step]) {
                this.checklistData.checklist[step] = [];
            }
            
            this.checklistData.checklist[step][item] = checkbox.checked;
        });
    },

    /**
     * Navega al paso anterior
     */
    prevStep() {
        if (this.currentStep > 1) {
            this.saveCheckboxesToData();
            this.currentStep--;
            this.updateWizard();
        }
    },

    /**
     * Navega al paso siguiente
     */
    nextStep() {
        if (this.currentStep < this.totalSteps) {
            this.saveCheckboxesToData();
            this.currentStep++;
            this.updateWizard();
        }
    },

    /**
     * Actualiza la visualización del wizard
     */
    updateWizard() {
        // Actualizar pasos visuales
        document.querySelectorAll('.step').forEach((step, index) => {
            step.classList.remove('active', 'completed');
            if (index + 1 === this.currentStep) {
                step.classList.add('active');
            } else if (index + 1 < this.currentStep) {
                step.classList.add('completed');
            }
        });

        // Actualizar barra de progreso
        const progress = (this.currentStep / this.totalSteps) * 100;
        document.getElementById('progressFill').style.width = progress + '%';

        // Actualizar pasos del wizard
        document.querySelectorAll('.wizard-step').forEach((step, index) => {
            step.classList.remove('active');
            if (index + 1 === this.currentStep) {
                step.classList.add('active');
            }
        });

        // Actualizar botones de navegación
        document.getElementById('btnPrev').disabled = this.currentStep === 1;
        document.getElementById('btnNext').style.display = this.currentStep < this.totalSteps ? 'flex' : 'none';
        document.getElementById('btnFinish').style.display = this.currentStep === this.totalSteps ? 'flex' : 'none';
    },

    /**
     * Selecciona si hubo entrada o no
     */
    selectTradeDecision(hadEntry) {
        console.log('selectTradeDecision llamado con:', hadEntry);
        
        // Marcar botón seleccionado
        document.querySelectorAll('.btn-decision').forEach(btn => btn.classList.remove('selected'));
        if (hadEntry) {
            document.getElementById('btnYesEntry')?.classList.add('selected');
        } else {
            document.getElementById('btnNoEntry')?.classList.add('selected');
        }

        // Mostrar formulario correspondiente
        const tradeForm = document.getElementById('tradeForm');
        const noEntryForm = document.getElementById('noEntryForm');
        
        if (tradeForm) tradeForm.style.display = hadEntry ? 'block' : 'none';
        if (noEntryForm) noEntryForm.style.display = hadEntry ? 'none' : 'block';

        this.checklistData.hadEntry = hadEntry;
        console.log('checklistData.hadEntry actualizado a:', this.checklistData.hadEntry);
    },

    /**
     * Calcula el R:R del trade
     */
    calculateRR() {
        const entry = document.getElementById('tradeEntry').value;
        const sl = document.getElementById('tradeSL').value;
        const tp = document.getElementById('tradeTP').value;

        const rr = StorageManager.calculateRR(entry, sl, tp);
        const rrField = document.getElementById('tradeRR');
        
        if (rr !== null) {
            rrField.value = `1:${rr}`;
            rrField.style.color = rr >= 1.2 ? '#22c55e' : '#FF3232';
        } else {
            rrField.value = '--';
        }
    },

    /**
     * Finaliza el wizard y guarda todos los datos
     */
    finishWizard() {
        // Guardar checkboxes finales
        this.saveCheckboxesToData();

        // Verificar que se haya seleccionado una opción (Sí o No)
        if (this.checklistData.hadEntry === undefined) {
            this.showToast('Por favor indica si hubo entrada hoy (SÍ o NO)', 'error');
            return;
        }

        // Validar y recopilar datos finales
        if (this.checklistData.hadEntry === true) {
            const tradeData = this.collectTradeData();
            if (!tradeData) {
                this.showToast('Por favor completa todos los campos requeridos del trade', 'error');
                return;
            }
            this.checklistData.tradeData = tradeData;
        } else if (this.checklistData.hadEntry === false) {
            this.checklistData.noEntryReasons = this.collectNoEntryReasons();
            this.checklistData.tradeData = null;
        }

        // Debug: ver qué se está guardando
        console.log('Guardando checklist:', this.checklistData);
        console.log('Checklist completion:', StorageManager.getChecklistCompletion(this.checklistData.checklist));
        
        // Guardar en storage
        StorageManager.saveTodayChecklist(this.checklistData);

        this.showToast('Checklist guardado exitosamente. Limpiando formulario...', 'success');
        
        // Limpiar TODO y empezar de nuevo
        setTimeout(() => {
            // Crear checklist vacío
            const checklist = {};
            StorageManager.CONFIG.STEPS.forEach(step => {
                checklist[step.id] = new Array(step.items).fill(false);
            });
            
            this.checklistData = {
                date: StorageManager.formatDateKey(StorageManager.getNYTime()),
                checklist,
                hadEntry: undefined,
                tradeData: null,
                noEntryReasons: [],
                notes: ''
            };
            
            // Limpiar todos los checkboxes
            document.querySelectorAll('[data-step][data-item]').forEach(checkbox => {
                checkbox.checked = false;
            });
            
            // Limpiar formularios del paso 8
            this.resetTradeForm();
            
            // Volver al paso 1
            this.currentStep = 1;
            this.updateWizard();
        }, 1000);
    },

    /**
     * Limpia los formularios del paso 8
     */
    resetTradeForm() {
        // Limpiar botones de decisión
        document.querySelectorAll('.btn-decision').forEach(btn => btn.classList.remove('selected'));
        
        // Ocultar formularios
        const tradeForm = document.getElementById('tradeForm');
        const noEntryForm = document.getElementById('noEntryForm');
        if (tradeForm) tradeForm.style.display = 'none';
        if (noEntryForm) noEntryForm.style.display = 'none';
        
        // Limpiar campos de trade
        const tradeNotes = document.getElementById('tradeNotes');
        if (tradeNotes) tradeNotes.value = '';
        
        // Limpiar radio buttons FVG
        document.querySelectorAll('input[name="fvgCount"]').forEach(radio => {
            radio.checked = false;
        });
        
        // Limpiar checkboxes de razones de no entrada
        for (let i = 1; i <= 5; i++) {
            const checkbox = document.getElementById(`reason${i}`);
            if (checkbox) checkbox.checked = false;
        }
        
        const noEntryNotes = document.getElementById('noEntryNotes');
        if (noEntryNotes) noEntryNotes.value = '';
        
        // Reset hadEntry en checklistData
        this.checklistData.hadEntry = undefined;
    },

    /**
     * Recopila los datos del trade
     */
    collectTradeData() {
        const notes = document.getElementById('tradeNotes')?.value.trim() || '';
        const fvgCount = document.querySelector('input[name="fvgCount"]:checked')?.value;

        console.log('Recopilando datos del trade:', {
            notes, fvgCount
        });

        if (!fvgCount) {
            console.error('Falta seleccionar FVG count');
            return null;
        }

        return {
            fvgCount: parseInt(fvgCount),
            notes,
            result: null, // Se actualizará cuando cierre el trade
            points: null
        };
    },

    /**
     * Recopila las razones de no entrada
     */
    collectNoEntryReasons() {
        const reasons = [];
        for (let i = 1; i <= 2; i++) {
            const checkbox = document.getElementById(`reason${i}`);
            if (checkbox && checkbox.checked) {
                reasons.push(checkbox.nextElementSibling.textContent.trim());
            }
        }

        const notes = document.getElementById('noEntryNotes').value.trim();
        if (notes) {
            reasons.push(`Notas: ${notes}`);
        }

        return reasons;
    },

    /**
     * Carga la vista de historial
     */
    loadHistoryView() {
        const filterPeriod = document.getElementById('filterPeriod').value;
        const filterType = document.getElementById('filterType').value;

        let history = StorageManager.getTradeHistory(filterPeriod);

        // Aplicar filtro de tipo
        if (filterType === 'withEntry') {
            history = history.filter(t => t.hadEntry);
        } else if (filterType === 'noEntry') {
            history = history.filter(t => !t.hadEntry);
        }

        const container = document.getElementById('historyList');
        
        if (history.length === 0) {
            container.innerHTML = `
                <div class="no-reflections">
                    <i class="fas fa-history"></i>
                    <h3>No hay registros todavía</h3>
                    <p>Completa tu primer checklist para ver el historial aquí</p>
                </div>
            `;
            return;
        }

        container.innerHTML = history.map(trade => this.renderHistoryItem(trade)).join('');
    },

    /**
     * Renderiza un item del historial
     */
    renderHistoryItem(trade) {
        const dateDisplay = StorageManager.formatDateDisplay(trade.date);
        const completion = StorageManager.getChecklistCompletion(trade.checklist);
        const statusClass = trade.hadEntry ? 'executed' : 'no-entry';
        const statusText = trade.hadEntry ? 'TRADE EJECUTADO' : 'SIN OPERACIÓN';

        if (!trade.hadEntry) {
            return `
                <div class="history-item no-entry">
                    <div class="history-header">
                        <span class="history-date">${dateDisplay}</span>
                        <span class="history-status ${statusClass}">${statusText}</span>
                    </div>
                    <div class="history-content">
                        <div class="history-field">
                            <label>Checklist</label>
                            <value>${completion}% completado</value>
                        </div>
                        <div class="history-field">
                            <label>Razones</label>
                            <value>${trade.noEntryReasons ? trade.noEntryReasons.join(', ') : 'No especificadas'}</value>
                        </div>
                    </div>
                </div>
            `;
        }

        const t = trade.tradeData;
        const resultClass = t.result === 'win' ? 'win' : t.result === 'loss' ? 'loss' : '';
        const resultText = t.result === 'win' ? '✅ WIN' : t.result === 'loss' ? '❌ LOSS' : '⏳ Pendiente';

        return `
            <div class="history-item ${resultClass}" data-trade-date="${trade.date}">
                <div class="history-header">
                    <span class="history-date">${dateDisplay}</span>
                    <span class="history-status ${statusClass}">${statusText}</span>
                </div>
                <div class="history-content">
                    <div class="history-field">
                        <label>FVG Count</label>
                        <value>${t.fvgCount} FVG</value>
                    </div>
                    <div class="history-field">
                        <label>Checklist</label>
                        <value>${completion}%</value>
                    </div>
                    <div class="history-field">
                        <label>Resultado</label>
                        <value>${resultText}</value>
                    </div>
                </div>
                ${t.notes ? `<div style="margin-top: 12px; opacity: 0.8;"><strong>Notas:</strong> ${t.notes}</div>` : ''}
                ${t.result === null ? `
                    <div class="trade-result-buttons">
                        <button class="btn-result-win" onclick="App.updateTradeResult('${trade.date}', 'win')">
                            <i class="fas fa-check-circle"></i> Marcar WIN
                        </button>
                        <button class="btn-result-loss" onclick="App.updateTradeResult('${trade.date}', 'loss')">
                            <i class="fas fa-times-circle"></i> Marcar LOSS
                        </button>
                    </div>
                ` : ''}
            </div>
        `;
    },

    /**
     * Carga la vista de estadísticas
     */
    loadStatisticsView() {
        const userData = StorageManager.getUserData();
        if (!userData) return;

        console.log('userData completo:', userData);
        console.log('estadísticas:', userData.statistics);

        const stats = userData.statistics;

        // Actualizar valores
        document.getElementById('statTotalDays').textContent = stats.totalDays;
        document.getElementById('statChecklistComplete').textContent = stats.checklistCompletePercentage + '%';
        document.getElementById('statWinRate').textContent = stats.winRate + '%';
        document.getElementById('statTotalPoints').textContent = stats.totalPoints > 0 ? '+' + stats.totalPoints : stats.totalPoints;

        // Renderizar gráficos
        this.renderWeekdayChart();
        this.renderCorrelationChart();
    },

    /**
     * Renderiza el gráfico de días de la semana
     */
    renderWeekdayChart() {
        const ctx = document.getElementById('weekdayChart');
        const data = StorageManager.getWeekdayStatistics();

        if (this.charts.weekday) {
            this.charts.weekday.destroy();
        }

        this.charts.weekday = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.labels,
                datasets: [{
                    label: 'Win Rate (%)',
                    data: data.data,
                    backgroundColor: '#FFD700',
                    borderColor: '#FFCE47',
                    borderWidth: 2,
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#2a2a2a',
                        titleColor: '#FFD700',
                        bodyColor: '#FFFFFF',
                        borderColor: '#FFD700',
                        borderWidth: 1
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            color: '#FFFFFF',
                            callback: value => value + '%'
                        },
                        grid: { color: 'rgba(255, 255, 255, 0.1)' }
                    },
                    x: {
                        ticks: { color: '#FFFFFF' },
                        grid: { color: 'rgba(255, 255, 255, 0.1)' }
                    }
                }
            }
        });
    },

    /**
     * Renderiza el gráfico de correlación
     */
    renderCorrelationChart() {
        const ctx = document.getElementById('correlationChart');
        const data = StorageManager.getChecklistCorrelation();

        if (this.charts.correlation) {
            this.charts.correlation.destroy();
        }

        this.charts.correlation = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.labels,
                datasets: [{
                    label: 'Win Rate (%)',
                    data: data.data,
                    backgroundColor: ['#22c55e', '#FF3232'],
                    borderWidth: 0,
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#2a2a2a',
                        titleColor: '#FFD700',
                        bodyColor: '#FFFFFF',
                        borderColor: '#FFD700',
                        borderWidth: 1
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            color: '#FFFFFF',
                            callback: value => value + '%'
                        },
                        grid: { color: 'rgba(255, 255, 255, 0.1)' }
                    },
                    x: {
                        ticks: { color: '#FFFFFF' },
                        grid: { display: false }
                    }
                }
            }
        });
    },

    /**
     * Exporta los datos a PDF
     */
    exportToPDF() {
        const exportData = StorageManager.getExportData();
        if (!exportData) {
            this.showToast('Error al exportar datos', 'error');
            return;
        }

        this.showToast('Generando PDF...', 'success');

        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        let yPos = 20;

        // Título
        doc.setFontSize(24);
        doc.setTextColor(255, 215, 0);
        doc.text('EDGECORE NASDAQ', 105, yPos, { align: 'center' });
        
        yPos += 10;
        doc.setFontSize(16);
        doc.setTextColor(255, 255, 255);
        doc.text('Reporte de Trading', 105, yPos, { align: 'center' });
        
        yPos += 15;
        doc.setFontSize(12);
        doc.setTextColor(200, 200, 200);
        doc.text(`Usuario: ${exportData.username}`, 20, yPos);
        doc.text(`Fecha: ${exportData.exportDate}`, 150, yPos);
        
        yPos += 15;

        // Estadísticas
        doc.setFontSize(16);
        doc.setTextColor(255, 215, 0);
        doc.text('Estadisticas', 20, yPos);
        yPos += 10;

        doc.setFontSize(11);
        doc.setTextColor(255, 255, 255);
        const stats = exportData.statistics;
        doc.text(`Dias Analizados: ${stats.totalDays}`, 25, yPos);
        yPos += 7;
        doc.text(`Dias con Entrada: ${stats.daysWithEntry}`, 25, yPos);
        yPos += 7;
        doc.text(`Win Rate: ${stats.winRate}%`, 25, yPos);
        yPos += 7;
        doc.text(`Total Puntos: ${stats.totalPoints}`, 25, yPos);
        yPos += 7;
        doc.text(`Checklist 100%: ${stats.checklistCompletePercentage}%`, 25, yPos);
        yPos += 15;

        // Guardar
        doc.save(`Edgecore_NASDAQ_${exportData.username}_${exportData.exportDate}.pdf`);
        
        this.showToast('PDF generado exitosamente', 'success');
    },

    /**
     * Actualiza el resultado de un trade
     */
    updateTradeResult(dateKey, result) {
        if (!confirm(`¿Confirmas que este trade fue un ${result === 'win' ? 'WIN' : 'LOSS'}?`)) {
            return;
        }

        const userData = StorageManager.getUserData();
        if (!userData || !userData.trades[dateKey]) {
            this.showToast('Error: No se encontró el trade', 'error');
            return;
        }

        const trade = userData.trades[dateKey];
        if (!trade.tradeData) {
            this.showToast('Error: El trade no tiene datos', 'error');
            return;
        }

        // Actualizar resultado (sin calcular puntos ya que no hay entry/sl/tp)
        trade.tradeData.result = result;
        trade.tradeData.points = 0; // Sin datos de precio, no podemos calcular puntos

        // Guardar
        StorageManager.updateStatistics(userData);
        StorageManager.saveUserData(userData);

        this.showToast(`Trade marcado como ${result === 'win' ? 'WIN' : 'LOSS'} exitosamente`, 'success');
        
        // Recargar historial
        this.loadHistoryView();
        
        // Si estamos en estadísticas, recargar también
        if (document.getElementById('statisticsView').classList.contains('active')) {
            this.loadStatisticsView();
        }
    },

    /**
     * Muestra una notificación toast
     */
    showToast(message, type = 'success') {
        const toast = document.getElementById('toast');
        toast.textContent = message;
        toast.className = `toast ${type} show`;

        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }
};

// Inicializar la aplicación cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});

// Guardar automáticamente antes de cerrar
window.addEventListener('beforeunload', () => {
    if (StorageManager.getCurrentUser() && App.checklistData) {
        App.saveCheckboxesToData();
    }
});
