/**
 * Sistema de almacenamiento para Edgecore NASDAQ Trading
 * Gestiona usuarios, trades y checklist diario usando localStorage
 */

const StorageManager = {
    // Claves para localStorage
    KEYS: {
        USERS: 'edgecore_nasdaq_users',
        CURRENT_USER: 'edgecore_nasdaq_current_user',
        USER_DATA: 'edgecore_nasdaq_data_'
    },

    // Configuración del sistema
    CONFIG: {
        INSTRUMENT: 'NASDAQ (NQ)',
        SESSION: 'Nueva York',
        WINDOW_START: '09:30',
        WINDOW_END: '10:15',
        TIMEZONE: 'America/New_York',
        
        STEPS: [
            {
                id: 'preparacion',
                name: 'Preparación Mental',
                items: 3
            },
            {
                id: 'mensual',
                name: 'Análisis Mensual',
                items: 2
            },
            {
                id: 'semanal',
                name: 'Análisis Semanal',
                items: 3
            },
            {
                id: 'diario',
                name: 'Análisis Diario',
                items: 4
            },
            {
                id: 'h4',
                name: 'Análisis 4H',
                items: 2
            },
            {
                id: 'h1',
                name: 'Análisis 1H',
                items: 3
            },
            {
                id: 'entrada',
                name: 'Modelo Entrada',
                items: 1
            },
            {
                id: 'registro',
                name: 'Registro Trade',
                items: 0
            }
        ]
    },

    /**
     * Inicializa el sistema de almacenamiento
     */
    init() {
        if (!localStorage.getItem(this.KEYS.USERS)) {
            localStorage.setItem(this.KEYS.USERS, JSON.stringify({}));
        }
    },

    /**
     * Registra un nuevo usuario
     */
    registerUser(username, password) {
        const users = this.getAllUsers();
        
        if (users[username]) {
            return { success: false, message: 'El usuario ya existe' };
        }

        if (username.length < 3) {
            return { success: false, message: 'El usuario debe tener al menos 3 caracteres' };
        }

        if (password.length < 6) {
            return { success: false, message: 'La contraseña debe tener al menos 6 caracteres' };
        }

        const hashedPassword = btoa(password);

        users[username] = {
            username,
            password: hashedPassword,
            createdAt: new Date().toISOString()
        };

        localStorage.setItem(this.KEYS.USERS, JSON.stringify(users));
        this.initUserData(username);

        return { success: true, message: 'Usuario registrado exitosamente' };
    },

    /**
     * Autentica un usuario
     */
    loginUser(username, password) {
        const users = this.getAllUsers();
        const user = users[username];

        if (!user) {
            return { success: false, message: 'Usuario no encontrado' };
        }

        const hashedPassword = btoa(password);
        if (user.password !== hashedPassword) {
            return { success: false, message: 'Contraseña incorrecta' };
        }

        localStorage.setItem(this.KEYS.CURRENT_USER, username);
        return { success: true, message: 'Inicio de sesión exitoso', user: username };
    },

    /**
     * Cierra la sesión del usuario actual
     */
    logoutUser() {
        localStorage.removeItem(this.KEYS.CURRENT_USER);
    },

    /**
     * Obtiene el usuario actual
     */
    getCurrentUser() {
        return localStorage.getItem(this.KEYS.CURRENT_USER);
    },

    /**
     * Obtiene todos los usuarios
     */
    getAllUsers() {
        const usersJson = localStorage.getItem(this.KEYS.USERS);
        return usersJson ? JSON.parse(usersJson) : {};
    },

    /**
     * Inicializa los datos de un usuario nuevo
     */
    initUserData(username) {
        const userData = {
            trades: {},
            statistics: {
                totalDays: 0,
                daysWithEntry: 0,
                totalWins: 0,
                totalLosses: 0,
                totalPoints: 0,
                checklistCompleteCount: 0
            }
        };

        const key = this.KEYS.USER_DATA + username;
        localStorage.setItem(key, JSON.stringify(userData));
    },

    /**
     * Obtiene los datos completos del usuario actual
     */
    getUserData() {
        const username = this.getCurrentUser();
        if (!username) return null;

        const key = this.KEYS.USER_DATA + username;
        const userDataJson = localStorage.getItem(key);
        return userDataJson ? JSON.parse(userDataJson) : null;
    },

    /**
     * Guarda los datos del usuario actual
     */
    saveUserData(userData) {
        const username = this.getCurrentUser();
        if (!username) return;

        const key = this.KEYS.USER_DATA + username;
        localStorage.setItem(key, JSON.stringify(userData));
    },

    /**
     * Obtiene los datos de un día específico
     */
    getDayData(date) {
        const userData = this.getUserData();
        if (!userData) return null;

        const dateKey = this.formatDateKey(date);
        return userData.trades[dateKey] || null;
    },

    /**
     * Guarda los datos de un día específico
     */
    saveDayData(date, dayData) {
        const userData = this.getUserData();
        if (!userData) return;

        const dateKey = this.formatDateKey(date);
        dayData.savedAt = new Date().toISOString();
        userData.trades[dateKey] = dayData;
        
        this.updateStatistics(userData);
        this.saveUserData(userData);
    },

    /**
     * Obtiene los datos del checklist de hoy (usando hora de Nueva York)
     */
    getTodayChecklist() {
        const todayNY = this.getNYTime();
        const dayData = this.getDayData(todayNY);
        
        if (!dayData) {
            // Retornar checklist vacío
            const checklist = {};
            this.CONFIG.STEPS.forEach(step => {
                checklist[step.id] = new Array(step.items).fill(false);
            });
            return {
                date: this.formatDateKey(todayNY),
                checklist,
                hadEntry: false,
                tradeData: null,
                noEntryReasons: [],
                notes: ''
            };
        }
        
        return dayData;
    },

    /**
     * Guarda el checklist de hoy (usando hora de Nueva York)
     */
    saveTodayChecklist(checklistData) {
        const todayNY = this.getNYTime();
        this.saveDayData(todayNY, checklistData);
    },

    /**
     * Calcula si el checklist está 100% completo
     */
    isChecklistComplete(checklist) {
        for (const step of this.CONFIG.STEPS) {
            // Saltar el paso de registro que tiene 0 items
            if (step.items === 0) {
                continue;
            }
            
            const stepData = checklist[step.id];
            console.log(`Verificando ${step.id}:`, stepData, 'items esperados:', step.items);
            
            if (!stepData || !stepData.every(item => item === true)) {
                console.log(`❌ ${step.id} no está completo`);
                return false;
            }
        }
        console.log('✅ Checklist 100% completo');
        return true;
    },

    /**
     * Calcula el porcentaje de completitud del checklist
     */
    getChecklistCompletion(checklist) {
        let totalItems = 0;
        let completedItems = 0;

        this.CONFIG.STEPS.forEach(step => {
            // Saltar steps con 0 items (como 'registro')
            if (step.items === 0) {
                return;
            }
            
            const stepData = checklist[step.id];
            if (stepData && Array.isArray(stepData)) {
                totalItems += step.items;
                
                // Solo contar los primeros step.items elementos (ignorar datos extra de versiones antiguas)
                const itemsToCount = stepData.slice(0, step.items);
                completedItems += itemsToCount.filter(item => item === true).length;
            }
        });

        return totalItems > 0 ? Math.round((completedItems / totalItems) * 100) : 0;
    },

    /**
     * Actualiza las estadísticas del usuario
     */
    updateStatistics(userData) {
        let totalDays = 0;
        let daysWithEntry = 0;
        let totalWins = 0;
        let totalLosses = 0;
        let totalPoints = 0;
        let checklistCompleteCount = 0;

        Object.values(userData.trades).forEach(dayData => {
            // FIX: Eliminar el campo 'registro' del checklist (no debe existir)
            if (dayData.checklist && dayData.checklist.registro) {
                delete dayData.checklist.registro;
            }
            
            totalDays++;

            // Verificar checklist completo
            if (this.isChecklistComplete(dayData.checklist)) {
                checklistCompleteCount++;
            }

            // Contar trades
            if (dayData.hadEntry && dayData.tradeData) {
                daysWithEntry++;
                
                if (dayData.tradeData.result === 'win') {
                    totalWins++;
                    totalPoints += dayData.tradeData.points || 0;
                } else if (dayData.tradeData.result === 'loss') {
                    totalLosses++;
                    totalPoints += dayData.tradeData.points || 0; // Los puntos negativos ya vienen con signo
                }
            }
        });

        userData.statistics = {
            totalDays,
            daysWithEntry,
            daysNoEntry: totalDays - daysWithEntry,
            totalWins,
            totalLosses,
            totalTrades: totalWins + totalLosses,
            winRate: (totalWins + totalLosses) > 0 ? Math.round((totalWins / (totalWins + totalLosses)) * 100) : 0,
            totalPoints: Math.round(totalPoints * 100) / 100,
            avgPointsPerTrade: (totalWins + totalLosses) > 0 ? Math.round((totalPoints / (totalWins + totalLosses)) * 100) / 100 : 0,
            checklistCompleteCount,
            checklistCompletePercentage: totalDays > 0 ? Math.round((checklistCompleteCount / totalDays) * 100) : 0
        };
    },

    /**
     * Obtiene el historial de trades
     */
    getTradeHistory(filterDays = 'all') {
        const userData = this.getUserData();
        if (!userData) return [];

        let trades = Object.entries(userData.trades).map(([date, data]) => ({
            date,
            ...data
        }));

        // Ordenar por fecha descendente
        trades.sort((a, b) => new Date(b.date) - new Date(a.date));

        // Aplicar filtro de días
        if (filterDays !== 'all') {
            const daysAgo = parseInt(filterDays);
            const cutoffDate = new Date();
            cutoffDate.setDate(cutoffDate.getDate() - daysAgo);
            
            trades = trades.filter(trade => new Date(trade.date) >= cutoffDate);
        }

        return trades;
    },

    /**
     * Calcula estadísticas por día de la semana
     */
    getWeekdayStatistics() {
        const userData = this.getUserData();
        if (!userData) return null;

        const weekdays = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
        const stats = weekdays.map(() => ({ trades: 0, wins: 0, losses: 0 }));

        Object.entries(userData.trades).forEach(([dateStr, data]) => {
            if (!data.hadEntry || !data.tradeData) return;

            const date = new Date(dateStr);
            const weekday = date.getDay();

            stats[weekday].trades++;
            if (data.tradeData.result === 'win') {
                stats[weekday].wins++;
            } else if (data.tradeData.result === 'loss') {
                stats[weekday].losses++;
            }
        });

        return {
            labels: weekdays,
            data: stats.map(s => s.trades > 0 ? Math.round((s.wins / s.trades) * 100) : 0)
        };
    },

    /**
     * Calcula correlación entre checklist y resultados
     */
    getChecklistCorrelation() {
        const userData = this.getUserData();
        if (!userData) return null;

        let complete100 = { trades: 0, wins: 0 };
        let completeBelow100 = { trades: 0, wins: 0 };

        Object.values(userData.trades).forEach(data => {
            if (!data.hadEntry || !data.tradeData) return;

            const isComplete = this.isChecklistComplete(data.checklist);

            if (isComplete) {
                complete100.trades++;
                if (data.tradeData.result === 'win') complete100.wins++;
            } else {
                completeBelow100.trades++;
                if (data.tradeData.result === 'win') completeBelow100.wins++;
            }
        });

        return {
            labels: ['Checklist 100%', 'Checklist <100%'],
            data: [
                complete100.trades > 0 ? Math.round((complete100.wins / complete100.trades) * 100) : 0,
                completeBelow100.trades > 0 ? Math.round((completeBelow100.wins / completeBelow100.trades) * 100) : 0
            ]
        };
    },

    /**
     * Formatea una fecha como clave (YYYY-MM-DD) usando zona horaria de Nueva York
     * Si recibe un objeto getNYTime(), usa su dateString
     * Si recibe un Date, lo convierte a NY timezone
     * Si recibe un string, lo retorna tal cual
     */
    formatDateKey(date) {
        // Si es el objeto retornado por getNYTime()
        if (date && typeof date === 'object' && date.dateString) {
            return date.dateString;
        }
        
        // Si es un string, retornarlo tal cual
        if (typeof date === 'string') {
            return date;
        }
        
        // Si es un Date object, convertir a NY timezone
        const formatter = new Intl.DateTimeFormat('en-US', {
            timeZone: this.CONFIG.TIMEZONE,
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        });
        
        const parts = formatter.formatToParts(date);
        const values = {};
        parts.forEach(part => {
            if (part.type !== 'literal') {
                values[part.type] = part.value;
            }
        });
        
        return `${values.year}-${values.month}-${values.day}`;
    },

    /**
     * Formatea una fecha para mostrar (usando zona horaria de Nueva York)
     * Recibe un dateString en formato YYYY-MM-DD
     */
    formatDateDisplay(dateStr) {
        // Parsear la fecha YYYY-MM-DD
        const [year, month, day] = dateStr.split('-').map(num => parseInt(num));
        
        // Crear fecha UTC para evitar conversiones de timezone
        const date = new Date(Date.UTC(year, month - 1, day, 12, 0, 0));
        
        const options = { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            timeZone: 'UTC' // Usar UTC ya que creamos la fecha en UTC
        };
        return date.toLocaleDateString('es-ES', options);
    },

    /**
     * Obtiene la hora actual de Nueva York
     * Retorna un objeto con componentes de fecha/hora en NY
     */
    getNYTime() {
        const now = new Date();
        const formatter = new Intl.DateTimeFormat('en-US', {
            timeZone: this.CONFIG.TIMEZONE,
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        });
        
        const parts = formatter.formatToParts(now);
        const values = {};
        parts.forEach(part => {
            if (part.type !== 'literal') {
                values[part.type] = part.value;
            }
        });
        
        return {
            year: parseInt(values.year),
            month: parseInt(values.month),
            day: parseInt(values.day),
            hour: parseInt(values.hour),
            minute: parseInt(values.minute),
            second: parseInt(values.second),
            dateString: `${values.year}-${values.month}-${values.day}`,
            timeString: `${values.hour}:${values.minute}`
        };
    },

    /**
     * Verifica si estamos dentro de la ventana de trading
     */
    isWithinTradingWindow() {
        const nyTime = this.getNYTime();
        const hours = nyTime.hour;
        const minutes = nyTime.minute;
        const currentMinutes = hours * 60 + minutes;

        const [startHour, startMin] = this.CONFIG.WINDOW_START.split(':').map(Number);
        const [endHour, endMin] = this.CONFIG.WINDOW_END.split(':').map(Number);

        const windowStart = startHour * 60 + startMin;
        const windowEnd = endHour * 60 + endMin;

        return currentMinutes >= windowStart && currentMinutes <= windowEnd;
    },

    /**
     * Formatea tiempo para mostrar
     * Recibe el objeto retornado por getNYTime() o un Date object
     */
    formatTime(timeObj) {
        // Si es el objeto de getNYTime()
        if (timeObj && typeof timeObj === 'object' && timeObj.timeString) {
            return timeObj.timeString;
        }
        
        // Si es un Date object (fallback)
        const hours = String(timeObj.getHours()).padStart(2, '0');
        const minutes = String(timeObj.getMinutes()).padStart(2, '0');
        return `${hours}:${minutes}`;
    },

    /**
     * Exporta todos los datos para PDF
     */
    getExportData() {
        const userData = this.getUserData();
        if (!userData) return null;

        const username = this.getCurrentUser();
        const history = this.getTradeHistory('all');

        return {
            username,
            exportDate: new Date().toLocaleDateString('es-ES'),
            statistics: userData.statistics,
            trades: history,
            config: this.CONFIG
        };
    },

    /**
     * Calcula R:R de un trade
     */
    calculateRR(entry, sl, tp) {
        entry = parseFloat(entry);
        sl = parseFloat(sl);
        tp = parseFloat(tp);

        if (!entry || !sl || !tp) return null;

        const risk = Math.abs(entry - sl);
        const reward = Math.abs(tp - entry);

        if (risk === 0) return null;

        const rr = reward / risk;
        return Math.round(rr * 10) / 10;
    }
};

// Inicializar el sistema de almacenamiento
StorageManager.init();
