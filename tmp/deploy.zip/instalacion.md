# 🚀 Instalación - Edgecore Trading App

## Requisitos Previos

### Navegador Web Moderno
- ✅ Google Chrome 90+ (Recomendado)
- ✅ Mozilla Firefox 88+
- ✅ Microsoft Edge 90+
- ✅ Safari 14+
- ✅ Opera 76+

### Requisitos del Sistema
- ✅ JavaScript habilitado
- ✅ Cookies/localStorage habilitado
- ✅ Conexión a internet (para CDN de librerías)
- ✅ Mínimo 10MB de espacio en localStorage

## Métodos de Instalación

### Opción 1: Uso Directo (Más Simple) ⭐ RECOMENDADO

1. **Descargar los archivos**
   - Descarga todos los archivos del proyecto
   - Mantén la estructura de carpetas intacta

2. **Abrir la aplicación**
   - Haz doble clic en `index.html`
   - O arrastra `index.html` a tu navegador

3. **¡Listo!**
   - La aplicación se abrirá automáticamente
   - Comienza registrándote

### Opción 2: Servidor Local (Para Desarrollo)

#### Usando Python (Si lo tienes instalado)
```bash
# Python 3
python -m http.server 8000

# Python 2
python -m SimpleHTTPServer 8000
```
Luego abre: `http://localhost:8000`

#### Usando Node.js (Si lo tienes instalado)
```bash
# Instalar http-server globalmente
npm install -g http-server

# Ejecutar en la carpeta del proyecto
http-server -p 8000
```
Luego abre: `http://localhost:8000`

#### Usando PHP (Si lo tienes instalado)
```bash
php -S localhost:8000
```
Luego abre: `http://localhost:8000`

### Opción 3: Extensión de VS Code (Para Desarrolladores)

1. Instala "Live Server" en VS Code
2. Click derecho en `index.html`
3. Selecciona "Open with Live Server"

## Verificación de Instalación

### 1. Verificar Estructura de Archivos
```
edgecore-trading/
├── index.html           ✅
├── css/
│   └── style.css       ✅
├── js/
│   ├── storage.js      ✅
│   └── app.js          ✅
├── README.md           ✅
├── GUIA_RAPIDA.md      ✅
├── NOTAS_TECNICAS.md   ✅
└── INSTALACION.md      ✅
```

### 2. Verificar Pantalla de Login
Al abrir `index.html` deberías ver:
- ✅ Logo de Edgecore Trading (icono de gráfico)
- ✅ Título "EDGECORE TRADING"
- ✅ Formulario de login
- ✅ Enlace para registro
- ✅ Colores: Fondo negro, texto blanco, acentos dorados

### 3. Verificar Consola del Navegador
1. Presiona `F12` para abrir DevTools
2. Ve a la pestaña "Console"
3. **No debería haber errores rojos**

### 4. Verificar localStorage
1. En DevTools, ve a "Application" (Chrome) o "Storage" (Firefox)
2. Busca "Local Storage"
3. Verifica que el dominio tenga acceso

## Solución de Problemas

### ❌ La página está en blanco
**Causas posibles:**
- JavaScript deshabilitado
- Archivos no descargados correctamente
- Estructura de carpetas incorrecta

**Solución:**
1. Habilita JavaScript en tu navegador
2. Verifica que todos los archivos estén presentes
3. Revisa la consola del navegador (F12) para errores

### ❌ No se ven los estilos (todo texto blanco sobre blanco)
**Causa:** El archivo CSS no se carga

**Solución:**
1. Verifica que `css/style.css` existe
2. Verifica la ruta en `index.html` línea 7
3. Si usas servidor local, asegúrate que está corriendo

### ❌ Los iconos no aparecen
**Causa:** Font Awesome no se carga (requiere internet)

**Solución:**
1. Verifica tu conexión a internet
2. Intenta recargar la página (F5)
3. Verifica que CDN de Font Awesome esté accesible

### ❌ Los gráficos no se muestran
**Causa:** Chart.js no se carga (requiere internet)

**Solución:**
1. Verifica tu conexión a internet
2. Ve a la vista de Estadísticas después de registrar datos
3. Verifica en consola si hay errores de Chart.js

### ❌ Error al exportar PDF
**Causa:** jsPDF no se carga (requiere internet)

**Solución:**
1. Verifica tu conexión a internet
2. Intenta nuevamente después de unos segundos
3. Verifica en consola si hay errores de jsPDF

### ❌ "localStorage is not defined"
**Causa:** localStorage bloqueado o no disponible

**Solución:**
1. Verifica configuración de privacidad del navegador
2. No uses modo incógnito (puede restringir localStorage)
3. Habilita cookies de primera parte
4. Si usas archivo directamente (file://), considera usar servidor local

### ❌ Los datos desaparecen al cerrar el navegador
**Causas posibles:**
- Modo incógnito activado
- Configuración de privacidad muy estricta
- Limpieza automática de datos

**Solución:**
1. No uses modo incógnito
2. Ajusta configuración de privacidad
3. Exporta PDF regularmente como respaldo

## Configuración Recomendada del Navegador

### Google Chrome
1. Configuración → Privacidad y seguridad
2. Cookies y otros datos de sitios
3. Permitir todas las cookies ✅
4. O agregar excepción para tu dominio local

### Mozilla Firefox
1. Opciones → Privacidad y seguridad
2. Historial → Firefox: Usará configuración personalizada
3. Aceptar cookies de sitios web ✅
4. No limpiar historial al cerrar Firefox

### Microsoft Edge
Similar a Chrome (basado en Chromium)

### Safari
1. Preferencias → Privacidad
2. Cookies y datos de sitios web
3. Permitir de sitios web que visito ✅

## Primer Uso Paso a Paso

### 1. Abrir la Aplicación
- Doble clic en `index.html`
- O desde servidor local: `http://localhost:8000`

### 2. Crear tu Cuenta
1. Click en "Regístrate aquí"
2. Elige un nombre de usuario (mín. 3 caracteres)
3. Crea una contraseña (mín. 6 caracteres)
4. Confirma tu contraseña
5. Click en "Registrarse"

### 3. Iniciar Sesión
1. Ingresa tu usuario
2. Ingresa tu contraseña
3. Click en "Entrar"

### 4. Pantalla de Bienvenida
1. Lee el mensaje de bienvenida
2. Click en "Comenzar mi Rutina"

### 5. Usar la Aplicación
1. Marca tus hábitos diarios ✅
2. Completa la reflexión semanal cada viernes
3. Click en "Guardar Progreso"
4. Explora las estadísticas y gráficos

## Actualizaciones

### Cómo Actualizar la Aplicación
Si recibes una versión actualizada:

1. **Backup de datos** (IMPORTANTE):
   - Ve a "Exportar" en la app
   - Descarga tu PDF actual
   - Esto preserva tu progreso

2. **Reemplazar archivos**:
   - Descarga los nuevos archivos
   - Reemplaza SOLO los archivos de código:
     - `index.html`
     - `css/style.css`
     - `js/storage.js`
     - `js/app.js`

3. **Verificar datos**:
   - Abre la aplicación
   - Inicia sesión
   - Verifica que tus datos siguen ahí

**NOTA**: Los datos en localStorage NO se borran al actualizar archivos HTML/CSS/JS

## Desinstalación

### Si quieres eliminar completamente la aplicación:

1. **Borrar archivos**:
   - Elimina la carpeta del proyecto

2. **Limpiar localStorage** (opcional):
   ```javascript
   // En consola del navegador (F12):
   localStorage.removeItem('edgecore_users');
   localStorage.removeItem('edgecore_current_user');
   // Para cada usuario:
   localStorage.removeItem('edgecore_user_data_[tu_usuario]');
   ```

3. **O limpiar todo localStorage del dominio**:
   ```javascript
   // En consola del navegador (F12):
   localStorage.clear();
   ```

**⚠️ ADVERTENCIA**: Esto borrará TODOS tus datos de forma permanente

## Migración de Datos

### Mover datos a otro dispositivo:

#### Opción 1: Exportar PDF (Simple, solo lectura)
1. Exporta tu progreso a PDF
2. Guarda el PDF en la nube o USB
3. Accede desde cualquier dispositivo

#### Opción 2: Copiar localStorage (Completo, editable)
```javascript
// En dispositivo origen (F12 → Console):
const data = {
  users: localStorage.getItem('edgecore_users'),
  current: localStorage.getItem('edgecore_current_user'),
  userData: localStorage.getItem('edgecore_user_data_[tu_usuario]')
};
console.log(JSON.stringify(data));
// Copiar el texto que aparece

// En dispositivo destino (F12 → Console):
const data = /* pegar el texto copiado */;
localStorage.setItem('edgecore_users', data.users);
localStorage.setItem('edgecore_current_user', data.current);
localStorage.setItem('edgecore_user_data_[tu_usuario]', data.userData);
// Recargar página
```

## Soporte Técnico

### Antes de pedir ayuda, verifica:
- ✅ Todos los archivos están presentes
- ✅ JavaScript está habilitado
- ✅ Conexión a internet funciona
- ✅ No hay errores en la consola del navegador (F12)
- ✅ localStorage está habilitado

### Información útil para reportar problemas:
- Navegador y versión (ej: Chrome 120)
- Sistema operativo (Windows/Mac/Linux)
- Mensaje de error exacto (captura de pantalla)
- Pasos para reproducir el problema

## Recursos Adicionales

### Documentación
- `README.md` - Documentación completa del proyecto
- `GUIA_RAPIDA.md` - Guía de uso para usuarios
- `NOTAS_TECNICAS.md` - Detalles técnicos para desarrolladores
- `INSTALACION.md` - Este archivo

### Enlaces Útiles
- Font Awesome: https://fontawesome.com/
- Chart.js: https://www.chartjs.org/
- jsPDF: https://github.com/parallax/jsPDF

---

**¿Problemas con la instalación?**  
Contacta al administrador de Edgecore Trading Club

**Instalación exitosa?**  
¡Comienza tu rutina de 12 semanas ahora! 🚀

*Última actualización: Octubre 2025*
