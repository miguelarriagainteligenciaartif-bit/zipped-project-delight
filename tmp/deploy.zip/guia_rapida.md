# 🚀 Guía Rápida - Edgecore Trading

## Inicio Rápido (3 pasos)

### 1️⃣ Primer Uso
1. Abre el archivo `index.html` en tu navegador
2. Haz clic en **"Regístrate aquí"**
3. Crea tu usuario y contraseña
4. Haz clic en **"Comenzar mi Rutina"**

### 2️⃣ Uso Diario
1. Inicia sesión con tu usuario
2. Marca los hábitos que completaste hoy ✅
3. Haz clic en **"Guardar Progreso"** (botón dorado)

### 3️⃣ Evaluación Semanal (Viernes)
1. Completa las dos preguntas de reflexión
2. Guarda el progreso
3. Revisa tus estadísticas 📊

## 📱 Acceso Rápido

### Menú Lateral
- **📋 Checklist**: Tu rutina diaria y semanal
- **📊 Estadísticas**: Gráficos y métricas de progreso
- **📚 Historial**: Todas tus reflexiones semanales
- **📄 Exportar**: Descargar tu progreso en PDF

### Navegación por Semanas
Usa los botones **◀ ▶** en la parte superior para moverte entre las 12 semanas.

## ✅ Los 9 Hábitos Diarios

1. ✅ Actividad física o al aire libre
2. ✅ Revisé data últimos meses
3. ✅ Medité antes de operar
4. ✅ Activé principios Edgecore
5. ✅ Respeté reglas sistema
6. ✅ Registré trade con data/emociones
7. ✅ Reflexioné ejecución
8. ✅ Ayuno cumplido
9. ✅ Alimentación saludable

## 💡 Tips Importantes

### ✨ Consejos de Uso
- ✅ **Marca diariamente**: No dejes acumular días
- ✅ **Sé honesto**: La herramienta es para tu beneficio
- ✅ **Reflexiona bien**: Las evaluaciones semanales son clave
- ✅ **Revisa estadísticas**: Te mantendrá motivado

### ⚠️ Importante
- ❌ **No borres el caché** del navegador (perderías tus datos)
- ❌ **No compartas** tu contraseña
- ✅ **Guarda regularmente** haciendo clic en "Guardar Progreso"
- ✅ **Exporta PDF** cada semana como respaldo

## 📊 Entendiendo tus Estadísticas

### 🔥 Racha Actual
Días consecutivos que has completado todos los hábitos

### 📈 Cumplimiento Semanal
Porcentaje de hábitos completados esta semana (de 45 posibles: 9 hábitos × 5 días)

### 🎯 Cumplimiento Total
Tu rendimiento en las 12 semanas completas

### 🏆 Mejor Racha
Tu récord personal de días consecutivos

## 📅 Calendario del Programa

- **Inicio**: 14 de octubre 2025
- **Fin**: 14 de enero 2026
- **Duración**: 12 semanas
- **Días activos**: Lunes a Viernes
- **Total**: 60 días de seguimiento

## 🎨 Código de Colores

- **🟡 Dorado**: Botones principales, títulos importantes
- **🔵 Azul**: Hover de botones, área de reflexión
- **🔴 Rojo**: Errores, botón de cerrar sesión
- **⚪ Blanco**: Texto principal
- **⚫ Negro**: Fondo

## 📄 Exportar a PDF

1. Ve a la sección **"Exportar"** en el menú
2. Selecciona qué incluir:
   - ✅ Checklists diarios
   - ✅ Reflexiones semanales
   - ✅ Estadísticas
3. Haz clic en **"Descargar PDF"**
4. El archivo se guardará con tu nombre de usuario y fecha

## ❓ Solución de Problemas

### No puedo iniciar sesión
- Verifica que el usuario y contraseña sean correctos
- Las contraseñas distinguen mayúsculas/minúsculas

### Se perdieron mis datos
- No borres el caché del navegador
- Usa siempre el mismo navegador y dispositivo
- Exporta PDF regularmente como respaldo

### Los gráficos no se ven
- Verifica tu conexión a internet (necesaria para Chart.js)
- Recarga la página (F5)

### El PDF no se genera
- Verifica tu conexión a internet (necesaria para jsPDF)
- Intenta nuevamente en unos segundos

## 🎯 Meta del Programa

Durante 12 semanas, construir hábitos sólidos de:
- 💪 Salud física y mental
- 📈 Disciplina en trading
- 📊 Análisis y reflexión constante
- 🎯 Excelencia operativa

## 🏆 Consejos para el Éxito

1. **Consistencia > Perfección**: Es mejor hacer 80% todos los días que 100% algunos días
2. **Reflexiona honestamente**: Las evaluaciones semanales son tu herramienta más valiosa
3. **Revisa tu progreso**: Cada domingo, revisa tus estadísticas
4. **Ajusta según necesites**: Usa tus reflexiones para mejorar
5. **Celebra tus rachas**: Cada día cuenta

## 📞 Soporte

Para problemas técnicos o dudas sobre el programa, contacta al administrador del club Edgecore Trading.

---

**¡Éxito en tu rutina de 12 semanas!** 🚀📈

*Última actualización: Octubre 2025*
