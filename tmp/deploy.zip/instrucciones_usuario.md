# 📋 INSTRUCCIONES - EDGECORE NASDAQ

## 🎯 ¿Qué es esta aplicación?

Sistema de **checklist diario** para operar **NASDAQ** en la sesión de Nueva York siguiendo la estrategia **Edgecore**. Te guía paso a paso cada día para mantener disciplina total y registrar tus operaciones.

---

## 🚀 PRIMER USO - REGISTRO

### **1. Crear tu cuenta**
1. Abre la aplicación
2. Haz clic en **"Regístrate aquí"**
3. Elige un **usuario** (mínimo 3 caracteres)
4. Crea una **contraseña** (mínimo 6 caracteres)
5. Confírma la contraseña
6. Haz clic en **"Registrarse"**

### **2. Iniciar sesión**
- Introduce tu usuario y contraseña
- Haz clic en **"Entrar"**
- ✅ Ya estás dentro

⚠️ **IMPORTANTE:** Guarda tus credenciales - NO hay recuperación de contraseña

---

## 📝 USO DIARIO - CHECKLIST COMPLETO

### **📌 RESUMEN RÁPIDO:**
Cada día debes completar **8 PASOS** en orden. Solo puedes hacer el checklist del **día de hoy**.

---

## **PASO 1: PREPARACIÓN MENTAL** ⏰ Antes de analizar

### ✅ **Qué hacer:**
1. ☑️ Limpiar y ordenar el espacio de trabajo
2. ☑️ Activar aromaterapia (difusor o incienso)
3. ☑️ Revisar objetivo del día

### 🎯 **Propósito:**
Entrar en el estado mental correcto antes de analizar mercados.

---

## **PASO 2: ANÁLISIS MENSUAL** 📅 Solo primer día del mes

### ✅ **Qué hacer:**
1. ☑️ Observar máximos mensuales
2. ☑️ Observar mínimos mensuales

### ⚠️ **IMPORTANTE:**
- **SOLO OBSERVAR** - NO marcar zonas
- Este paso se hace **SOLO el día 1 del mes**
- El resto del mes lo saltas

---

## **PASO 3: ANÁLISIS SEMANAL** 📅 Solo los lunes

### ✅ **Qué hacer:**
1. ☑️ Revisar calendario de noticias económicas de la semana
2. ☑️ Observar máximos semanales
3. ☑️ Observar mínimos semanales

### ⚠️ **IMPORTANTE:**
- **SOLO OBSERVAR** - NO marcar zonas
- Este paso se hace **SOLO los lunes**
- Martes a viernes lo saltas

---

## **PASO 4: ANÁLISIS DIARIO** 📅 Cada día a las 9:15 AM (NY)

### ✅ **Qué hacer:**
1. ☑️ Revisar calendario de noticias del día
2. ☑️ Marcar máximos diarios en gráfico
3. ☑️ Marcar mínimos diarios en gráfico
4. ☑️ **Marcar zonas de interés:** FVG, OB, 50OB

### 🎯 **AQUÍ SÍ MARCAS ZONAS** ✅
- Priorizar la zona más cercana al precio
- No tocar la zona lejana

---

## **PASO 5: ANÁLISIS 4H** 🕐 Refinamiento

### ✅ **Qué hacer:**
1. ☑️ Verificar confluencias con zonas diarias
2. ☑️ **Marcar zonas de interés 4H:** FVG, OB, 50OB

### 🎯 **Objetivo:**
- Refinar las zonas marcadas en diario
- Buscar confluencias

---

## **PASO 6: ANÁLISIS 1H** ⏰ Entre 9:27 - 9:29 AM (NY)

### ✅ **Qué hacer:**
1. ☑️ Verificar confluencias con zonas de diario y H4
2. ☑️ Identificar zonas de 1H cercanas al precio actual
3. ☑️ **Determinar la dirección del precio con la vela de H1 entre las 9:27 y 9:29 hora New York**

### ⚠️ **IMPORTANTE:**
- **NO marcas punto de entrada en H1**
- Solo verificas confluencias y determinas dirección
- Observar forma, mechas y volumen de la vela

---

## **PASO 7: MODELO DE ENTRADA** 🎯 A las 9:30 AM (NY)

### ✅ **Qué hacer:**
1. ☑️ Desplazamiento confirmado a las 9:30 AM
2. ☑️ FVG formado a las 9:30 AM
3. ☑️ Todos los análisis multi-timeframe completos

### ⚠️ **VENTANA DE EJECUCIÓN:**
**SOLO 9:30 - 10:15 AM (Nueva York)**

Si NO se cumplen las condiciones en esta ventana → **NO hay entrada hoy**

---

## **PASO 8: REGISTRO DEL TRADE** 📝 Decisión final

### **A. ¿Hubo entrada hoy?**

Primero decides: **¿Ejecutaste un trade o no?**

---

### **✅ SI EJECUTASTE TRADE:**

#### **1. Selecciona FVG Count**
Elige cuántos FVG identificaste:

**1 FVG:**
- Ejecutar en el único FVG
- SL: Proteger 3 velas del FVG
- Si no hay R:R mínimo 1:1.2, esperar descuento

**2 FVG:**
- Ejecutar en el ÚLTIMO FVG
- SL: Proteger 3 velas del 1er FVG
- Si no hay R:R 1:1.2, descuento o vela envolvente

**3+ FVG:**
- Esperar protocolo vela envolvente
- NO ejecutar sin protocolo

#### **2. Añade Notas (opcional)**
Escribe observaciones del trade si quieres.

#### **3. Guarda**
Haz clic en **"Finalizar y Guardar"**

---

### **❌ SI NO EJECUTASTE TRADE:**

#### **1. Marca razones:**
☑️ No se formó FVG a las 9:30 AM
☑️ No hubo desplazamiento
☑️ R:R no era mínimo 1:1.2
☑️ Setup no cumplió todos los criterios
☑️ Fuera de ventana 9:30-10:15 AM

#### **2. Añade notas (opcional)**
Describe qué observaste hoy.

#### **3. Guarda**
Haz clic en **"Finalizar y Guardar"**

---

## 📊 ACTUALIZAR RESULTADOS DE TRADES

### **⚠️ PASO CRÍTICO PARA ESTADÍSTICAS**

Después de registrar un trade, aparece como **"⏳ Pendiente"**

**Cuando el trade cierre (alcance TP o SL):**

1. Ve al menú lateral → **"Historial"**
2. Busca tu trade pendiente
3. Verás dos botones:
   - **"Marcar WIN"** ✅ (si alcanzó el TP)
   - **"Marcar LOSS"** ❌ (si tocó el SL)
4. Haz clic según el resultado
5. Confirma
6. ✅ **Las estadísticas se actualizan automáticamente**

### **📌 MUY IMPORTANTE:**
- Solo los trades con resultado (WIN/LOSS) cuentan en las estadísticas
- Los trades pendientes NO afectan el Win Rate
- **Debes actualizar manualmente** cuando cierre el trade

---

## 📈 VER ESTADÍSTICAS

Ve al menú lateral → **"Estadísticas"**

### **Verás:**
- **Win Rate** - Porcentaje de trades ganados
- **Días Analizados** - Total de días con checklist
- **Checklist 100%** - % de días que completaste al 100%
- **Total Puntos** - Puntos ganados/perdidos (actualmente en 0 porque no se registran precios)
- **Gráficos:**
  - Resultados por día de la semana
  - Correlación: Checklist completo vs Resultados

---

## 📚 HISTORIAL

Ve al menú lateral → **"Historial"**

### **Puedes:**
- Ver todos tus días de trading
- Filtrar por período (7, 30, 90 días o todos)
- Filtrar por tipo (con entrada, sin entrada)
- **Actualizar resultados pendientes** (WIN/LOSS)

---

## 🎯 REGLAS DE MARCAJE DE ZONAS

| Temporalidad | ¿Marcar zonas? | Acción |
|--------------|----------------|--------|
| **Mensual** | ❌ NO | Solo observar contexto macro |
| **Semanal** | ❌ NO | Solo observar contexto |
| **Diario** | ✅ SÍ | Marcar FVG, OB, 50OB |
| **4H** | ✅ SÍ | Marcar FVG, OB, 50OB |
| **1H** | ⚠️ NO | Solo confluencias, no punto de entrada |

---

## ⚠️ REGLAS IMPORTANTES

### **🕐 Ventana de Ejecución:**
- **SOLO entre 9:30 - 10:15 AM (Nueva York)**
- Fuera de esta ventana = NO hay entrada
- **No negociable**

### **📊 R:R Mínimo:**
- **Mínimo 1:1.2** (Riesgo-Beneficio)
- Si no alcanza → NO ejecutar

### **🚫 Break Even PROHIBIDO:**
- **NO mover el Stop Loss**
- Solo esperar TP o SL inicial
- Sin excepciones

### **📅 Un día = Un checklist:**
- Solo puedes hacer el checklist del **día de hoy**
- **NO puedes rellenar días pasados** (evita trampas)
- Mañana harás el de mañana

---

## 💾 TUS DATOS - IMPORTANTE

### **✅ Dónde se guardan:**
- En tu **navegador** (localStorage)
- **NO se envían a ningún servidor**
- Son **100% privados**
- Cada usuario tiene sus propios datos separados

### **⚠️ CUIDADO - Puedes perder datos si:**
- ❌ Borras el caché del navegador
- ❌ Borras datos del sitio web
- ❌ Usas modo incógnito (se borra al cerrar)
- ❌ Cambias de navegador (Chrome → Firefox)
- ❌ Cambias de dispositivo (PC → móvil)

### **✅ Recomendaciones:**
- Usa siempre el **mismo navegador**
- **NO borres caché** del navegador
- Haz **capturas de pantalla** de tus estadísticas importantes
- Usa **mismo dispositivo** siempre

---

## 🔒 SEGURIDAD Y PRIVACIDAD

✅ Tus datos están **solo en tu navegador**
✅ Nadie más puede verlos
✅ No se comparten con nadie
✅ No necesitas internet después de cargar la app
✅ Cada usuario ve solo sus propios datos
⚠️ NO hay recuperación de contraseña - guarda tus credenciales

---

## 🆘 PROBLEMAS COMUNES

### **No puedo iniciar sesión**
- Verifica usuario y contraseña (distingue MAYÚSCULAS de minúsculas)
- Asegúrate de estar usando el mismo navegador donde te registraste

### **Perdí mis datos**
- Si borraste el caché del navegador, se perdieron permanentemente
- No hay forma de recuperarlos
- Por eso es importante hacer capturas de pantalla

### **Las estadísticas muestran 0%**
- Asegúrate de marcar **TODOS los checkboxes** de todos los pasos
- Verifica que actualizaste el resultado del trade (WIN/LOSS)

### **No puedo marcar los botones SÍ/NO en el paso 8**
- Recarga la página (F5)
- Intenta hacer clic directamente en el texto del botón

### **El checklist sigue lleno después de guardar**
- Es normal si es el **mismo día**
- El checklist de HOY se mantiene hasta mañana
- Mañana empezarás con uno nuevo limpio

---

## 💡 CONSEJOS PARA MEJORES RESULTADOS

1. ✅ **Completa el checklist ANTES de las 9:30 AM**
2. ✅ **Sé honesto** con cada checkbox
3. ✅ **NO fuerces entradas** fuera de la ventana 9:30-10:15 AM
4. ✅ **Actualiza resultados** inmediatamente cuando el trade cierre
5. ✅ **Revisa estadísticas** cada semana para ver tu progreso
6. ✅ **Haz capturas de pantalla** de tus mejores trades
7. ✅ **Respeta las reglas FVG** sin excepciones
8. ✅ **NO muevas el SL** - break even prohibido
9. ✅ **Usa el mismo navegador** siempre
10. ✅ **Disciplina total** - PROHIBIDO DUDAR

---

## 📱 COMPATIBILIDAD

### **Navegadores soportados:**
✅ Google Chrome (recomendado)
✅ Microsoft Edge
✅ Mozilla Firefox
✅ Safari

### **Dispositivos:**
✅ Computadora de escritorio (mejor experiencia)
✅ Laptop
✅ Tablet
✅ Móvil (funcional pero menos cómodo)

### **Requisitos:**
✅ JavaScript habilitado
✅ Cookies/localStorage habilitado

---

## 🎓 LOS 10 CONCEPTOS CLAVE

1. **El Poder de la Espera** - Preparación mental antes de todo
2. **Análisis Top-Down** - Mensual (observar) → Semanal (observar) → Diario/4H/1H (marcar)
3. **Ventana Estricta** - Solo 9:30-10:15 AM (NY) - sin excepciones
4. **Reglas FVG** - 1, 2 o 3+ FVG tienen protocolos diferentes
5. **R:R Mínimo 1:1.2** - No negociable
6. **Sin Break Even** - NO mover Stop Loss
7. **NASDAQ Únicamente** - Enfoque en un solo instrumento
8. **Sesión NY** - Una sesión, un horario
9. **Actualizar Resultados** - Marca WIN/LOSS cuando cierre el trade
10. **Disciplina Total** - PROHIBIDO DUDAR

---

## 📞 SOPORTE

### **¿Problemas técnicos?**
- Recarga la página (F5 o Ctrl+F5)
- Cierra y abre el navegador
- Verifica que JavaScript esté habilitado
- Usa Chrome o Edge para mejor experiencia

### **¿Perdiste la contraseña?**
- NO hay recuperación automática
- Tendrás que crear un nuevo usuario
- Por eso es importante guardar tus credenciales

---

## ✅ CHECKLIST RÁPIDO DIARIO

**Antes de las 9:15 AM:**
- [ ] Paso 1: Preparación Mental
- [ ] Paso 2: Mensual (solo día 1 del mes)
- [ ] Paso 3: Semanal (solo lunes)
- [ ] Paso 4: Diario (9:15 AM) - **Marcar zonas**

**Antes de las 9:30 AM:**
- [ ] Paso 5: 4H - **Marcar zonas**
- [ ] Paso 6: 1H (9:27-9:29 AM) - **Confluencias**

**A las 9:30 AM:**
- [ ] Paso 7: Confirmar entrada

**Durante 9:30-10:15 AM:**
- [ ] Paso 8: Registrar decisión (SÍ/NO)

**Después del cierre:**
- [ ] Ir al Historial
- [ ] Marcar WIN o LOSS

---

**🚀 ¡Listo para operar con máxima disciplina!**

*"La disciplina es el puente entre metas y logros"*

---

**Versión:** 2.0  
**Fecha:** Octubre 2025  
**Estado:** ✅ ACTUALIZADO
